const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const PORT = 3000;

const app = express();
app.use(express.json());
app.use(cors());

// database connectivity
mongoose.connect('mongodb://localhost:27017/Marketplace', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const db = mongoose.connection;
db.on('error', (error) => {
  console.error(`Don't connect with Database dur to :${error}`);
});
db.once('open', () => {
  console.log(`Successfully Connected with MongoDB.`);
});

// routes

const productRoutes = require('./routes/productRoutes');
app.use('/api', productRoutes);

const categoryRoutes = require('./routes/categoryRoutes');
app.use('/api', categoryRoutes);

app.get('/', (req, res) => {
  res.json({ message: 'Welcome to DressStore application' });
});

app.listen(PORT, () => {
  console.log(`Server Listening on Port: ${PORT}`);
});
