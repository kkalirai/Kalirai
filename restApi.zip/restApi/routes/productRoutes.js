const express = require('express');
const router = express.Router();
const Product = require('../models/product');
const Category = require('../models/category');

// GET all products
router.get('/products', async (req, res) => {
  try {
    const products = await Product.find();
    res.json(products);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET a product by ID
router.get('/products/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    res.json(product);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST a new product
router.post('/products', async (req, res) => {
  const product = new Product({
    name: req.body.name,
    description: req.body.description,
    price: req.body.price,
    quantity: req.body.quantity,
    category: req.body.category,
  });

  try {
    const newProduct = await product.save();
    res.status(201).json(newProduct);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// PUT (update) a product by ID
router.put('/products/:id', async (req, res) => {
  try {
    const updatedProduct = await Product.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    res.json(updatedProduct);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// DELETE a product by ID
router.delete('/products/:id', async (req, res) => {
  try {
    await Product.findByIdAndRemove(req.params.id);
    res.json({ message: 'Product deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// DELETE all products
router.delete('/products', async (req, res) => {
  try {
    const deletedProducts = await Product.deleteMany({});
    if (!deletedProducts) {
      return res.status(404).json({ message: 'No products found' });
    }
    res.json({ message: 'All products deleted', deletedProducts });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});
// GET products by name containing a keyword
router.get('/products', async (req, res) => {
  try {
    const keyword = req.query.name;
    if (!keyword) {
      return res.status(400).json({ message: 'Name keyword is required' });
    }

    // Use a case-insensitive regular expression to find products by name
    const products = await Product.find({
      name: { $regex: new RegExp(keyword, 'i') },
    });

    if (products.length === 0) {
      return res
        .status(404)
        .json({ message: 'No products found with the given keyword' });
    }

    res.json(products);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
