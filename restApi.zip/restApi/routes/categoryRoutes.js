const express = require('express');
const router = express.Router();
const Category = require('../models/category');

// GET all categories
router.get('/category', async (req, res) => {
  try {
    const category = await Category.find();
    res.json(category);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET a category by ID
router.get('/category/:id', async (req, res) => {
  try {
    const category = await Category.findById(req.params.id);
    res.json(category);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST a new category
router.post('/category', async (req, res) => {
  const category = new Category({
    name: req.body.name,
  });

  try {
    const newCategory = await category.save();
    res.status(201).json(newCategory);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// PUT (update) a category by ID
router.put('/category/:id', async (req, res) => {
  try {
    const updatedCategory = await Category.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    res.json(updatedCategory);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// DELETE a category by ID
router.delete('/category/:id', async (req, res) => {
  try {
    await Category.findByIdAndRemove(req.params.id);
    res.json({ message: 'Category deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// DELETE all categories
router.delete('/category', async (req, res) => {
  try {
    const deletedCategories = await Category.deleteMany({});
    if (!deletedCategories) {
      return res.status(404).json({ message: 'No categories found' });
    }
    res.json({ message: 'All categories deleted', deletedCategories });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
